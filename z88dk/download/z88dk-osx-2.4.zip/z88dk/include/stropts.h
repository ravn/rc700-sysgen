#ifndef __STROPTS_H__
#define __STROPTS_H__

#include <sys/ioctl.h>

#endif
