

#ifndef __ARCH_H__
#define __ARCH_H__


#ifdef __SPECTRUM
#include <../libsrc/_DEVELOPMENT/target/zx/config_zx.h>
#endif

#ifdef __ZXNEXT
#include <../libsrc/_DEVELOPMENT/target/zxn/config_zxn.h>
#endif


#endif

