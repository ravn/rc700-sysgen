

#ifndef __ALLOC_H__
#define __ALLOC_H__

#include <alloc/balloc.h>
#include <alloc/obstack.h>

#endif
