
#ifndef __IOPORT_H__
#define __IOPORT_H__

extern char __LIB__ IOPORT_Read( char port );
extern void __LIB__ IOPORT_Set( char port, char value ) __smallc;

#endif /* __IOPORT_H__ */
