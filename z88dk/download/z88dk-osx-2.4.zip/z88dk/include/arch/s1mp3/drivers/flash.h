

#ifndef __FLASH_H__
#define __FLASH_H__

/* Init */
extern void __LIB__ FLASH_Initialise( void );

extern void __LIB__ FLASH_PageRead( void );

#endif /* __FLASH_H__ */

