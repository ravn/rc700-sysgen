
#ifndef __USB_H__
#define __USB_H__

#include <ATJ2085_Ports.h>

extern void __LIB__ USB_Initialise( void );
extern void __LIB__ USB_ISR( void );

#endif /* __USB_H__ */

