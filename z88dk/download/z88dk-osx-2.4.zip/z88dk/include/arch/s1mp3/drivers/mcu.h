#ifndef __MCU_H__
#define __MCU_H__

#include <ATJ2085_Ports.h>

extern void __LIB__ MCU_Initialise( unsigned char Clock_Divider );

#endif
