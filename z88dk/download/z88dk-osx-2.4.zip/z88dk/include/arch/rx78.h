

#ifndef __ARCH_RX78_H__
#define __ARCH_RX78_H__

// Load the palette
extern void __LIB__ load_palette(unsigned char *data, int index, int count) __smallc;

#endif
