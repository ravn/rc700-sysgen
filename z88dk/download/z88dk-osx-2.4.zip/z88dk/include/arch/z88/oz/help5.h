/*
 *      Help File for Commands in Topic 5
 *
 *      Don't include yourself!!!
 */


#ifdef TOPIC5_1HELP1
.in_com_hlp5_1
        defb    0x7F
        HELPTEXT(TOPIC5_1HELP1)
#ifdef TOPIC5_1HELP2
        HELPTEXT(TOPIC5_1HELP2)
#endif
#ifdef TOPIC5_1HELP3
        HELPTEXT(TOPIC5_1HELP3)
#endif
#ifdef TOPIC5_1HELP4
        HELPTEXT(TOPIC5_1HELP4)
#endif
#ifdef TOPIC5_1HELP5
        HELPTEXT(TOPIC5_1HELP5)
#endif
#ifdef TOPIC5_1HELP6
        HELPTEXT(TOPIC5_1HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_1HELP1 - overall  */

#ifdef TOPIC5_2HELP1
.in_com_hlp5_2
        defb    0x7F
        HELPTEXT(TOPIC5_2HELP1)
#ifdef TOPIC5_2HELP2
        HELPTEXT(TOPIC5_2HELP2)
#endif
#ifdef TOPIC5_2HELP3
        HELPTEXT(TOPIC5_2HELP3)
#endif
#ifdef TOPIC5_2HELP4
        HELPTEXT(TOPIC5_2HELP4)
#endif
#ifdef TOPIC5_2HELP5
        HELPTEXT(TOPIC5_2HELP5)
#endif
#ifdef TOPIC5_2HELP6
        HELPTEXT(TOPIC5_2HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_2HELP1 - overall  */


#ifdef TOPIC5_3HELP1
.in_com_hlp5_3
        defb    0x7F
        HELPTEXT(TOPIC5_3HELP1)
#ifdef TOPIC5_3HELP2
        HELPTEXT(TOPIC5_3HELP2)
#endif
#ifdef TOPIC5_3HELP3
        HELPTEXT(TOPIC5_3HELP3)
#endif
#ifdef TOPIC5_3HELP4
        HELPTEXT(TOPIC5_3HELP4)
#endif
#ifdef TOPIC5_3HELP5
        HELPTEXT(TOPIC5_3HELP5)
#endif
#ifdef TOPIC5_3HELP6
        HELPTEXT(TOPIC5_3HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_3HELP1 - overall  */




#ifdef TOPIC5_4HELP1
.in_com_hlp5_4
        defb    0x7F
        HELPTEXT(TOPIC5_4HELP1)
#ifdef TOPIC5_4HELP2
        HELPTEXT(TOPIC5_4HELP2)
#endif
#ifdef TOPIC5_4HELP3
        HELPTEXT(TOPIC5_4HELP3)
#endif
#ifdef TOPIC5_4HELP4
        HELPTEXT(TOPIC5_4HELP4)
#endif
#ifdef TOPIC5_4HELP5
        HELPTEXT(TOPIC5_4HELP5)
#endif
#ifdef TOPIC5_4HELP6
        HELPTEXT(TOPIC5_4HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_4HELP1 - overall  */


#ifdef TOPIC5_5HELP1
.in_com_hlp5_5
        defb    0x7F
        HELPTEXT(TOPIC5_5HELP1)
#ifdef TOPIC5_5HELP2
        HELPTEXT(TOPIC5_5HELP2)
#endif
#ifdef TOPIC5_5HELP3
        HELPTEXT(TOPIC5_5HELP3)
#endif
#ifdef TOPIC5_5HELP4
        HELPTEXT(TOPIC5_5HELP4)
#endif
#ifdef TOPIC5_5HELP5
        HELPTEXT(TOPIC5_5HELP5)
#endif
#ifdef TOPIC5_5HELP6
        HELPTEXT(TOPIC5_5HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_5HELP1 - overall  */


#ifdef TOPIC5_6HELP1
.in_com_hlp5_6
        defb    0x7F
        HELPTEXT(TOPIC5_6HELP1)
#ifdef TOPIC5_6HELP2
        HELPTEXT(TOPIC5_6HELP2)
#endif
#ifdef TOPIC5_6HELP3
        HELPTEXT(TOPIC5_6HELP3)
#endif
#ifdef TOPIC5_6HELP4
        HELPTEXT(TOPIC5_6HELP4)
#endif
#ifdef TOPIC5_6HELP5
        HELPTEXT(TOPIC5_6HELP5)
#endif
#ifdef TOPIC5_6HELP6
        HELPTEXT(TOPIC5_6HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_6HELP1 - overall  */


#ifdef TOPIC5_7HELP1
.in_com_hlp5_7
        defb    0x7F
        HELPTEXT(TOPIC5_7HELP1)
#ifdef TOPIC5_7HELP2
        HELPTEXT(TOPIC5_7HELP2)
#endif
#ifdef TOPIC5_7HELP3
        HELPTEXT(TOPIC5_7HELP3)
#endif
#ifdef TOPIC5_7HELP4
        HELPTEXT(TOPIC5_7HELP4)
#endif
#ifdef TOPIC5_7HELP5
        HELPTEXT(TOPIC5_7HELP5)
#endif
#ifdef TOPIC5_7HELP6
        HELPTEXT(TOPIC5_7HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_7HELP1 - overall  */


#ifdef TOPIC5_8HELP1
.in_com_hlp5_8
        defb    0x7F
        HELPTEXT(TOPIC5_8HELP1)
#ifdef TOPIC5_8HELP2
        HELPTEXT(TOPIC5_8HELP2)
#endif
#ifdef TOPIC5_8HELP3
        HELPTEXT(TOPIC5_8HELP3)
#endif
#ifdef TOPIC5_8HELP4
        HELPTEXT(TOPIC5_8HELP4)
#endif
#ifdef TOPIC5_8HELP5
        HELPTEXT(TOPIC5_8HELP5)
#endif
#ifdef TOPIC5_8HELP6
        HELPTEXT(TOPIC5_8HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_8HELP1 - overall  */


#ifdef TOPIC5_9HELP1
.in_com_hlp5_9
        defb    0x7F
        HELPTEXT(TOPIC5_9HELP1)
#ifdef TOPIC5_9HELP2
        HELPTEXT(TOPIC5_9HELP2)
#endif
#ifdef TOPIC5_9HELP3
        HELPTEXT(TOPIC5_9HELP3)
#endif
#ifdef TOPIC5_9HELP4
        HELPTEXT(TOPIC5_9HELP4)
#endif
#ifdef TOPIC5_9HELP5
        HELPTEXT(TOPIC5_9HELP5)
#endif
#ifdef TOPIC5_9HELP6
        HELPTEXT(TOPIC5_9HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_9HELP1 - overall  */


#ifdef TOPIC5_10HELP1
.in_com_hlp5_10
        defb    0x7F
        HELPTEXT(TOPIC5_10HELP1)
#ifdef TOPIC5_10HELP2
        HELPTEXT(TOPIC5_10HELP2)
#endif
#ifdef TOPIC5_10HELP3
        HELPTEXT(TOPIC5_10HELP3)
#endif
#ifdef TOPIC5_10HELP4
        HELPTEXT(TOPIC5_10HELP4)
#endif
#ifdef TOPIC5_10HELP5
        HELPTEXT(TOPIC5_10HELP5)
#endif
#ifdef TOPIC5_10HELP6
        HELPTEXT(TOPIC5_10HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_10HELP1 - overall  */


#ifdef TOPIC5_11HELP1
.in_com_hlp5_11
        defb    0x7F
        HELPTEXT(TOPIC5_11HELP1)
#ifdef TOPIC5_11HELP2
        HELPTEXT(TOPIC5_11HELP2)
#endif
#ifdef TOPIC5_11HELP3
        HELPTEXT(TOPIC5_11HELP3)
#endif
#ifdef TOPIC5_11HELP4
        HELPTEXT(TOPIC5_11HELP4)
#endif
#ifdef TOPIC5_11HELP5
        HELPTEXT(TOPIC5_11HELP5)
#endif
#ifdef TOPIC5_11HELP6
        HELPTEXT(TOPIC5_11HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_11HELP1 - overall  */


#ifdef TOPIC5_12HELP1
.in_com_hlp5_12
        defb    0x7F
        HELPTEXT(TOPIC5_12HELP1)
#ifdef TOPIC5_12HELP2
        HELPTEXT(TOPIC5_12HELP2)
#endif
#ifdef TOPIC5_12HELP3
        HELPTEXT(TOPIC5_12HELP3)
#endif
#ifdef TOPIC5_12HELP4
        HELPTEXT(TOPIC5_12HELP4)
#endif
#ifdef TOPIC5_12HELP5
        HELPTEXT(TOPIC5_12HELP5)
#endif
#ifdef TOPIC5_12HELP6
        HELPTEXT(TOPIC5_12HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_12HELP1 - overall  */


#ifdef TOPIC5_13HELP1
.in_com_hlp5_13
        defb    0x7F
        HELPTEXT(TOPIC5_13HELP1)
#ifdef TOPIC5_13HELP2
        HELPTEXT(TOPIC5_13HELP2)
#endif
#ifdef TOPIC5_13HELP3
        HELPTEXT(TOPIC5_13HELP3)
#endif
#ifdef TOPIC5_13HELP4
        HELPTEXT(TOPIC5_13HELP4)
#endif
#ifdef TOPIC5_13HELP5
        HELPTEXT(TOPIC5_13HELP5)
#endif
#ifdef TOPIC5_13HELP6
        HELPTEXT(TOPIC5_13HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_13HELP1 - overall  */


#ifdef TOPIC5_14HELP1
.in_com_hlp5_14
        defb    0x7F
        HELPTEXT(TOPIC5_14HELP1)
#ifdef TOPIC5_14HELP2
        HELPTEXT(TOPIC5_14HELP2)
#endif
#ifdef TOPIC5_14HELP3
        HELPTEXT(TOPIC5_14HELP3)
#endif
#ifdef TOPIC5_14HELP4
        HELPTEXT(TOPIC5_14HELP4)
#endif
#ifdef TOPIC5_14HELP5
        HELPTEXT(TOPIC5_14HELP5)
#endif
#ifdef TOPIC5_14HELP6
        HELPTEXT(TOPIC5_14HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_14HELP1 - overall  */


#ifdef TOPIC5_15HELP1
.in_com_hlp5_15
        defb    0x7F
        HELPTEXT(TOPIC5_15HELP1)
#ifdef TOPIC5_15HELP2
        HELPTEXT(TOPIC5_15HELP2)
#endif
#ifdef TOPIC5_15HELP3
        HELPTEXT(TOPIC5_15HELP3)
#endif
#ifdef TOPIC5_15HELP4
        HELPTEXT(TOPIC5_15HELP4)
#endif
#ifdef TOPIC5_15HELP5
        HELPTEXT(TOPIC5_15HELP5)
#endif
#ifdef TOPIC5_15HELP6
        HELPTEXT(TOPIC5_15HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_15HELP1 - overall  */


#ifdef TOPIC5_16HELP1
.in_com_hlp5_16
        defb    0x7F
        HELPTEXT(TOPIC5_16HELP1)
#ifdef TOPIC5_16HELP2
        HELPTEXT(TOPIC5_16HELP2)
#endif
#ifdef TOPIC5_16HELP3
        HELPTEXT(TOPIC5_16HELP3)
#endif
#ifdef TOPIC5_16HELP4
        HELPTEXT(TOPIC5_16HELP4)
#endif
#ifdef TOPIC5_16HELP5
        HELPTEXT(TOPIC5_16HELP5)
#endif
#ifdef TOPIC5_16HELP6
        HELPTEXT(TOPIC5_16HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_16HELP1 - overall  */


#ifdef TOPIC5_17HELP1
.in_com_hlp5_17
        defb    0x7F
        HELPTEXT(TOPIC5_17HELP1)
#ifdef TOPIC5_17HELP2
        HELPTEXT(TOPIC5_17HELP2)
#endif
#ifdef TOPIC5_17HELP3
        HELPTEXT(TOPIC5_17HELP3)
#endif
#ifdef TOPIC5_17HELP4
        HELPTEXT(TOPIC5_17HELP4)
#endif
#ifdef TOPIC5_17HELP5
        HELPTEXT(TOPIC5_17HELP5)
#endif
#ifdef TOPIC5_17HELP6
        HELPTEXT(TOPIC5_17HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_17HELP1 - overall  */


#ifdef TOPIC5_18HELP1
.in_com_hlp5_18
        defb    0x7F
        HELPTEXT(TOPIC5_18HELP1)
#ifdef TOPIC5_18HELP2
        HELPTEXT(TOPIC5_18HELP2)
#endif
#ifdef TOPIC5_18HELP3
        HELPTEXT(TOPIC5_18HELP3)
#endif
#ifdef TOPIC5_18HELP4
        HELPTEXT(TOPIC5_18HELP4)
#endif
#ifdef TOPIC5_18HELP5
        HELPTEXT(TOPIC5_18HELP5)
#endif
#ifdef TOPIC5_18HELP6
        HELPTEXT(TOPIC5_18HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_18HELP1 - overall  */


#ifdef TOPIC5_19HELP1
.in_com_hlp5_19
        defb    0x7F
        HELPTEXT(TOPIC5_19HELP1)
#ifdef TOPIC5_19HELP2
        HELPTEXT(TOPIC5_19HELP2)
#endif
#ifdef TOPIC5_19HELP3
        HELPTEXT(TOPIC5_19HELP3)
#endif
#ifdef TOPIC5_19HELP4
        HELPTEXT(TOPIC5_19HELP4)
#endif
#ifdef TOPIC5_19HELP5
        HELPTEXT(TOPIC5_19HELP5)
#endif
#ifdef TOPIC5_19HELP6
        HELPTEXT(TOPIC5_19HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_19HELP1 - overall  */


#ifdef TOPIC5_20HELP1
.in_com_hlp5_20
        defb    0x7F
        HELPTEXT(TOPIC5_20HELP1)
#ifdef TOPIC5_20HELP2
        HELPTEXT(TOPIC5_20HELP2)
#endif
#ifdef TOPIC5_20HELP3
        HELPTEXT(TOPIC5_20HELP3)
#endif
#ifdef TOPIC5_20HELP4
        HELPTEXT(TOPIC5_20HELP4)
#endif
#ifdef TOPIC5_20HELP5
        HELPTEXT(TOPIC5_20HELP5)
#endif
#ifdef TOPIC5_20HELP6
        HELPTEXT(TOPIC5_20HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_20HELP1 - overall  */


#ifdef TOPIC5_21HELP1
.in_com_hlp5_21
        defb    0x7F
        HELPTEXT(TOPIC5_21HELP1)
#ifdef TOPIC5_21HELP2
        HELPTEXT(TOPIC5_21HELP2)
#endif
#ifdef TOPIC5_21HELP3
        HELPTEXT(TOPIC5_21HELP3)
#endif
#ifdef TOPIC5_21HELP4
        HELPTEXT(TOPIC5_21HELP4)
#endif
#ifdef TOPIC5_21HELP5
        HELPTEXT(TOPIC5_21HELP5)
#endif
#ifdef TOPIC5_21HELP6
        HELPTEXT(TOPIC5_21HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_21HELP1 - overall  */


#ifdef TOPIC5_22HELP1
.in_com_hlp5_22
        defb    0x7F
        HELPTEXT(TOPIC5_22HELP1)
#ifdef TOPIC5_22HELP2
        HELPTEXT(TOPIC5_22HELP2)
#endif
#ifdef TOPIC5_22HELP3
        HELPTEXT(TOPIC5_22HELP3)
#endif
#ifdef TOPIC5_22HELP4
        HELPTEXT(TOPIC5_22HELP4)
#endif
#ifdef TOPIC5_22HELP5
        HELPTEXT(TOPIC5_22HELP5)
#endif
#ifdef TOPIC5_22HELP6
        HELPTEXT(TOPIC5_22HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_22HELP1 - overall  */


#ifdef TOPIC5_23HELP1
.in_com_hlp5_23
        defb    0x7F
        HELPTEXT(TOPIC5_23HELP1)
#ifdef TOPIC5_23HELP2
        HELPTEXT(TOPIC5_23HELP2)
#endif
#ifdef TOPIC5_23HELP3
        HELPTEXT(TOPIC5_23HELP3)
#endif
#ifdef TOPIC5_23HELP4
        HELPTEXT(TOPIC5_23HELP4)
#endif
#ifdef TOPIC5_23HELP5
        HELPTEXT(TOPIC5_23HELP5)
#endif
#ifdef TOPIC5_23HELP6
        HELPTEXT(TOPIC5_23HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_23HELP1 - overall  */


#ifdef TOPIC5_24HELP1
.in_com_hlp5_24
        defb    0x7F
        HELPTEXT(TOPIC5_24HELP1)
#ifdef TOPIC5_24HELP2
        HELPTEXT(TOPIC5_24HELP2)
#endif
#ifdef TOPIC5_24HELP3
        HELPTEXT(TOPIC5_24HELP3)
#endif
#ifdef TOPIC5_24HELP4
        HELPTEXT(TOPIC5_24HELP4)
#endif
#ifdef TOPIC5_24HELP5
        HELPTEXT(TOPIC5_24HELP5)
#endif
#ifdef TOPIC5_24HELP6
        HELPTEXT(TOPIC5_24HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5_24HELP1 - overall  */
