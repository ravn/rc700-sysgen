/*
 *      Help File for Commands in Topics
 *
 *      Don't include yourself!!!
 */


#ifdef TOPIC1HELP1
.in_topic1_hlp
        defb    0x7F
        HELPTEXT(TOPIC1HELP1)
#ifdef TOPIC1HELP2
        HELPTEXT(TOPIC1HELP2)
#endif
#ifdef TOPIC1HELP3
        HELPTEXT(TOPIC1HELP3)
#endif
#ifdef TOPIC1HELP4
        HELPTEXT(TOPIC1HELP4)
#endif
#ifdef TOPIC1HELP5
        HELPTEXT(TOPIC1HELP5)
#endif
#ifdef TOPIC1HELP6
        HELPTEXT(TOPIC1HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC1HELP1 - overall  */


#ifdef TOPIC2HELP1
.in_topic2_hlp
        defb    0x7F
        HELPTEXT(TOPIC2HELP1)
#ifdef TOPIC2HELP2
        HELPTEXT(TOPIC2HELP2)
#endif
#ifdef TOPIC2HELP3
        HELPTEXT(TOPIC2HELP3)
#endif
#ifdef TOPIC2HELP4
        HELPTEXT(TOPIC2HELP4)
#endif
#ifdef TOPIC2HELP5
        HELPTEXT(TOPIC2HELP5)
#endif
#ifdef TOPIC2HELP6
        HELPTEXT(TOPIC2HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC2HELP1 - overall  */


#ifdef TOPIC3HELP1
.in_topic3_hlp
        defb    0x7F
        HELPTEXT(TOPIC3HELP1)
#ifdef TOPIC3HELP2
        HELPTEXT(TOPIC3HELP2)
#endif
#ifdef TOPIC3HELP3
        HELPTEXT(TOPIC3HELP3)
#endif
#ifdef TOPIC3HELP4
        HELPTEXT(TOPIC3HELP4)
#endif
#ifdef TOPIC3HELP5
        HELPTEXT(TOPIC3HELP5)
#endif
#ifdef TOPIC3HELP6
        HELPTEXT(TOPIC3HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC3HELP1 - overall  */


#ifdef TOPIC4HELP1
.in_topic4_hlp
        defb    0x7F
        HELPTEXT(TOPIC4HELP1)
#ifdef TOPIC4HELP2
        HELPTEXT(TOPIC4HELP2)
#endif
#ifdef TOPIC4HELP3
        HELPTEXT(TOPIC4HELP3)
#endif
#ifdef TOPIC4HELP4
        HELPTEXT(TOPIC4HELP4)
#endif
#ifdef TOPIC4HELP5
        HELPTEXT(TOPIC4HELP5)
#endif
#ifdef TOPIC4HELP6
        HELPTEXT(TOPIC4HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4HELP1 - overall  */


#ifdef TOPIC5HELP1
.in_topic5_hlp
        defb    0x7F
        HELPTEXT(TOPIC5HELP1)
#ifdef TOPIC5HELP2
        HELPTEXT(TOPIC5HELP2)
#endif
#ifdef TOPIC5HELP3
        HELPTEXT(TOPIC5HELP3)
#endif
#ifdef TOPIC5HELP4
        HELPTEXT(TOPIC5HELP4)
#endif
#ifdef TOPIC5HELP5
        HELPTEXT(TOPIC5HELP5)
#endif
#ifdef TOPIC5HELP6
        HELPTEXT(TOPIC5HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC5HELP1 - overall  */


#ifdef TOPIC6HELP1
.in_topic6_hlp
        defb    0x7F
        HELPTEXT(TOPIC6HELP1)
#ifdef TOPIC6HELP2
        HELPTEXT(TOPIC6HELP2)
#endif
#ifdef TOPIC6HELP3
        HELPTEXT(TOPIC6HELP3)
#endif
#ifdef TOPIC6HELP4
        HELPTEXT(TOPIC6HELP4)
#endif
#ifdef TOPIC6HELP5
        HELPTEXT(TOPIC6HELP5)
#endif
#ifdef TOPIC6HELP6
        HELPTEXT(TOPIC6HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC6HELP1 - overall  */


#ifdef TOPIC7HELP1
.in_topic7_hlp
        defb    0x7F
        HELPTEXT(TOPIC7HELP1)
#ifdef TOPIC7HELP2
        HELPTEXT(TOPIC7HELP2)
#endif
#ifdef TOPIC7HELP3
        HELPTEXT(TOPIC7HELP3)
#endif
#ifdef TOPIC7HELP4
        HELPTEXT(TOPIC7HELP4)
#endif
#ifdef TOPIC7HELP5
        HELPTEXT(TOPIC7HELP5)
#endif
#ifdef TOPIC7HELP6
        HELPTEXT(TOPIC7HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC7HELP1 - overall  */


