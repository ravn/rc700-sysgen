
#ifndef ARCH_TRS80_EG2000_H
#define ARCH_TRS80_EG2000_H

#define EG2000_PALETTE_MODE_NORTHERN 0
#define EG2000_PALETTE_MODE_SOUTHERN 1

extern void __LIB__ eg2000_switch_palette_mode(int mode);

#endif
