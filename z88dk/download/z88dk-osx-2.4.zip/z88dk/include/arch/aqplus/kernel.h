#if __AQPLUS_FIRMWARE_023q
	#include	"kernel_023q.h"
#elif __AQPLUS_FIRMWARE_023i
	#include	"kernel_023i.h"
#else
	#include	"kernel_023q.h"
#endif
