/*
 *	Standard library for z88dk
 *
 *	A concession to ISO C
 *
 *	$Id: iso646.h,v 1.3 2001-10-16 18:30:31 dom Exp $
 */


#ifndef __ISO646_H__
#define __ISO646_H__

#define and && 
#define and_eq &= 
#define bitand & 
#define bitor | 
#define compl ~ 
#define not ! 
#define not_eq != 
#define or || 
#define or_eq |= 
#define xor ^ 
#define xor_eq ^= 

#endif

